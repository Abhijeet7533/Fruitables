#!C:\Python312\python.exe
import cgi
import cgitb
import Header
cgitb.enable()
import mysql.connector
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
UserID=form.getvalue("UserID")
#print(UserID)
mydb = mysql.connector.connect(
    host="127.0.0.1",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor = mydb.cursor(dictionary=True) 
mycursorr = mydb.cursor(dictionary=True)
query=f""" SELECT * FROM cart WHERE UserID='{UserID}' """

query1=f""" SELECT * FROM register WHERE id='{UserID}' """

#print(query1)
mycursor.execute(query)
myresult=mycursor.fetchall()
#print(myresult)
total_amount = 0

for x in myresult:
    price = int(x['Price'].split()[0])   # FIXED
    quantity = int(x['Quantity'])
    total_amount += price * quantity

mycursor1=mydb.cursor(dictionary=True)
query1=f"""SELECT * from register WHERE id={UserID}"""  
#print(query1)  
mycursor1.execute(query1)
myresult1=mycursor1.fetchone()
#print(myresult1) 
print(f"""
<!DOCTYPE html>
<html lang="en">
<!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Checkout</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-white">Checkout</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Checkout Page Start -->
        <div class="container-fluid py-5">
            <div class="container py-5">
                <h1 class="mb-4">Billing details</h1>
                <form action="#">
                    <div class="row g-5">
                        <div class="col-md-12 col-lg-6 col-xl-7">
                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">First Name</label>
                                        <input type="text" class="form-control" value="{myresult1['FirstName']}">


                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">Last Name</label>
                                        <input type="text" class="form-control" value="{myresult1['LastName']}">
                                    </div>
                                </div>
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Email</label>
                                <input type="text" class="form-control" value="{myresult1['Email']}">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Street</label>
                                <input type="text" class="form-control" value="{myresult1['Street']}">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">City</label>
                                <input type="text" class="form-control" value="{myresult1['City']}">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">PinCode</label>
                                <input type="text" class="form-control" value="{myresult1['PinCode']}">
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">PhoneNumber</label>
                                <input type="text" class="form-control" value="{myresult1['PhoneNumber']}">
                            </div>
                            
                        </div>
                       
                                        <tr>
                                            <th scope="row">
                                            </th>
                                            <td class="py-5">
                                                <p >YOUR ORDER</p>
                                                <p >TOTAL AMOUNT </p>
                                            </td>
                                            <td class="py-5"></td>
                                            <td class="py-5"></td>
                                            <td class="py-5">
                                                <div class="py-3 border-bottom border-top">
                                                    <p class="mb-0 text-dark">RS {total_amount}</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            
                            
                            
                            <div class="row g-4 text-center align-items-center justify-content-center pt-4">
                                <button type="button" class="btn border-secondary py-3 px-4 text-uppercase w-100 text-primary"><a  href="Order.py?UserID={UserID}&total_amount={total_amount}">Place Order</a></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Checkout Page End -->


        
""")
import Footer