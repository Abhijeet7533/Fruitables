#!C:\Python312\python.exe
import cgi
import cgitb
import Header
import mysql.connector
cgitb.enable()
print("Content-Type: text/html\n")
mydb = mysql.connector.connect(
    host="localhost",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor=mydb.cursor(dictionary=True)
query=f""" SELECT * FROM about """
#print(query)
mycursor.execute(query)
myresult=mycursor.fetchone()
#print(myresult)
print(f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us</title>
</head>

<body>

<!-- Page Header Start -->
<div class="container-fluid page-header py-5">
    <h1 class="text-center text-white display-6">About Us</h1>
    <ol class="breadcrumb justify-content-center mb-0">
        <li class="breadcrumb-item"><a href="Index.py">Home</a></li>
        <li class="breadcrumb-item active text-white">About</li>
    </ol>
</div>
<!-- Page Header End -->

<!-- About Start -->
<div class="container-fluid py-5">
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6">
                <img src="img/hero-img-1.png" class="img-fluid w-100 h-100 bg-secondary rounded" alt="First slide">
            </div>
            <div class="col-lg-6">
                <h2>{myresult['Store']}</h2>
            </div>
        </div>
    </div>
</div>
<!-- About End -->

<!-- Why Choose Us Start -->
<div class="container-fluid bg-light py-5">
    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 class="mb-3">Why Choose Us</h1>
        </div>
        <div class="row g-4 text-center">
            <h1>{myresult['Choose']}</h1>
        </div>
    </div>
</div>
<!-- Why Choose Us End -->

</body>
</html>
""")
import Footer
