#!C:\Python312\python.exe
import cgi
import cgitb 
cgitb.enable()
print("Content-Type: text/html\n")
print("""
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Fruitables - Vegetable Website Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
        <style>
      .hidden {
    display: none !important;
}
      </style>
    </head>
<!-- Navbar start -->
        <div class="container-fluid fixed-top">
            <div class="container topbar bg-primary d-none d-lg-block">
                <div class="d-flex justify-content-between">
                    <div class="top-info ps-2">
                        <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-secondary"></i> <a href="#" class="text-white">123 Street, New York</a></small>
                        <small class="me-3"><i class="fas fa-envelope me-2 text-secondary"></i><a href="#" class="text-white">Email@Example.com</a></small>
                    </div>
                    <div class="top-link pe-2">
                        <a href="#" class="text-white"><small class="text-white mx-2">Privacy Policy</small>/</a>
                        <a href="#" class="text-white"><small class="text-white mx-2">Terms of Use</small>/</a>
                        <a href="#" class="text-white"><small class="text-white ms-2">Sales and Refunds</small></a>
                    </div>
                </div>
            </div>
            <div class="container px-0">
                <nav class="navbar navbar-light bg-white navbar-expand-xl">
                    <a href="index.html" class="navbar-brand"><h1 class="text-primary display-6">Fruitables</h1></a>
                    <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars text-primary"></span>
                    </button>
                    <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                        <div class="navbar-nav mx-auto">
                            <a href="Index.py" class="nav-item nav-link active">Home</a>
                            <a href="About.py" class="nav-item nav-link">About</a>
                            <a href="Product.py" class="nav-item nav-link">Product</a>
                            <a href="Product_Details.py" class="nav-item nav-link">Product Detail</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu m-0 bg-secondary rounded-0">
                                    <a href="Cart.py" class="dropdown-item">Cart</a>
                                    <a href="Checkout.py" class="dropdown-item">Chackout</a>
                                    <a href="Testimonial.py" class="dropdown-item">Testimonial</a>
                                    <a href="404.py" class="dropdown-item">404 Page</a>
                                </div>
                            </div>
                            <a href="Contact.py" class="nav-item nav-link">Contact</a>




<li id="nav-register"><a href="Registration.py" class="nav-item nav-link">Registration</a></li>
<li id="nav-login"><a href="Login.py" class="nav-item nav-link">Login</a></li>

<div class="nav-item dropdown">
    <li id="nav-user" class="hidden">
        <a href="#" class="nav-item nav-link"><span id="FirstName"></span></a>
      
      
    </li>
       <li>
        <a href="#" class="nav-item nav-link" id="UserIdLink">My Profile</a>
      </li>
</div>

<li id="nav-logout" class="hidden">
    <a href="Logout.py" class="nav-item nav-link">Logout</a>
</li>





                        </div>
                        <div class="d-flex m-3 me-0">
                            <button class="btn-search btn border border-secondary btn-md-square rounded-circle bg-white me-4" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="fas fa-search text-primary"></i></button>
                            <a href="Cart.py" class="position-relative me-4 my-auto">
                                <i class="fa fa-shopping-bag fa-2x"></i>
                                <span class="position-absolute bg-secondary rounded-circle d-flex align-items-center justify-content-center text-dark px-1" style="top: -5px; left: 15px; height: 20px; min-width: 20px;">3</span>
                            </a>
                            
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Navbar End -->
        <script>
    document.addEventListener("DOMContentLoaded", function () {
        let firstName = localStorage.getItem("FirstName");
      let UserID = localStorage.getItem("id");
      let urllink="myProfile.py?UserID="+UserID;
      

        if (firstName) {
            document.getElementById("FirstName").textContent = firstName;
      document.getElementById("UserIdLink").href = urllink;
     
            document.getElementById("nav-register").classList.add("hidden");
            document.getElementById("nav-login").classList.add("hidden");

            document.getElementById("nav-user").classList.remove("hidden");
            document.getElementById("nav-logout").classList.remove("hidden");
        } else {
            document.getElementById("nav-register").classList.remove("hidden");
            document.getElementById("nav-login").classList.remove("hidden");

            document.getElementById("nav-user").classList.add("hidden");
            document.getElementById("nav-logout").classList.add("hidden");
        }
    });
</script>
""")