#!C:\Python312\python.exe
import cgi
import cgitb
import mysql.connector
cgitb.enable()
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
FirstName=form.getvalue("FirstName")
#print(FirstName)
LastName=form.getvalue("LastName")
#print(LastName)
Email=form.getvalue("Email")
#print(Email)
Street=form.getvalue("Street")
#print(Street)
City=form.getvalue("City")
#print(City)
PinCode=form.getvalue("PinCode")
#print(PinCode)
PhoneNumber=form.getvalue("PhoneNumber")
#print(PhoneNumber)
Password=form.getvalue("Password")
#print(Password)
mydb = mysql.connector.connect(
    host="127.0.0.1",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor = mydb.cursor()
query=f"INSERT INTO register (FirstName,LastName,Email,Street,City,PinCode,PhoneNumber,Password) values ('{FirstName}', '{LastName}', '{Email}', '{Street}', '{City}', '{PinCode}', '{PhoneNumber}', '{Password}')"""
#print(query)
mycursor.execute(query)
mydb.commit()
print(f'''
    <script>alert(" Register Successfully!");
    location.href="Login.py";
    </script>''')