#!C:\Python312\python.exe
import cgi
import cgitb
cgitb.enable()
import mysql.connector
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
email=form.getvalue("email")
#print(email)
password=form.getvalue("password")
#print(password)
mydb = mysql.connector.connect(
    host="127.0.0.1",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor = mydb.cursor()
query=f""" SELECT * FROM adminlogin WHERE email='{email}' AND password='{password}'"""
#print(query)
mycursor.execute(query)
myresult=mycursor.fetchone()
if mycursor.rowcount==1:
    
    print(f'''
    <script>alert(" Login Successfully!");
    location.href="Product.py";
    </script>''')
else:
    print(f'''
    <script>alert(" Login Unsuccessfully!");
    location.href="AdminLogin.py";
    </script>''')