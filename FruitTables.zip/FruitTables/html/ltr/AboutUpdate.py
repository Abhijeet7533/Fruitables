#!C:\Python312\python.exe
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html\n")
import mysql.connector
form=cgi.FieldStorage()
id=form.getvalue("id")
#print(form)
Store=form.getvalue("Store")
#print(Store)

Choose=form.getvalue("Choose")
#print(Choose)

mydb = mysql.connector.connect(
    host="localhost",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
#print(mydb)
mycursor=mydb.cursor()
query=f""" UPDATE about SET Store='{Store}' , Choose='{Choose}' WHERE id={id}"""
#print(query)   
mycursor.execute(query)
mydb.commit()
print(f'''
    <script>alert(" About Update Successfully");
    location.href="AboutList.py";
    </script>''')
