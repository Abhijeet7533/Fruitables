#!C:\Python312\python.exe
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html\n")
import mysql.connector
form=cgi.FieldStorage()
id=form.getvalue("id")
#print(form)
Address=form.getvalue("Address")
#print(Address)
Mail=form.getvalue("Mail")
#print(Mail)
PhoneNumber=form.getvalue("PhoneNumber")
#print(PhoneNumber)

mydb = mysql.connector.connect(
    host="localhost",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
#print(mydb)
mycursor=mydb.cursor()
query=f""" UPDATE contact SET Address='{Address}' , Mail='{Mail}' , PhoneNumber='{PhoneNumber}' WHERE id={id}"""
#print(query)   
mycursor.execute(query)
mydb.commit()
print(f'''
    <script>alert(" Contact Update Successfully");
    location.href="ContactList.py";
    </script>''')
