#!C:\Python312\python.exe
import cgi
import cgitb
import mysql.connector
cgitb.enable()
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
id=form.getvalue("id")
#print(id)
mydb = mysql.connector.connect(
    host="127.0.0.1",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor=mydb.cursor()
query=f""" DELETE FROM product WHERE Id={id}"""
#print(query)
mycursor.execute(query)
mydb.commit()
print(f'''
    <script>alert(" Product Delete Successfully!");
    location.href="ProductList.py";
    </script>''')
