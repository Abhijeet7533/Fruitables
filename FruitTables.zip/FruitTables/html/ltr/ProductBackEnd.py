#!C:\Python312\python.exe
import cgi
import cgitb
import os
import mysql.connector
cgitb.enable()
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
ProductName=form.getvalue("ProductName")
#print(ProductName)
Price=form.getvalue("Price")
#print(Price)
Description=form.getvalue("Description")
#print(Description)
fi=form["Photo"]
#print(fi.filename)
fn=os.path.splitext(fi.filename)
#print(fn[0])
uploudFileName='abc'+fn[1]
mydb = mysql.connector.connect(
    host="127.0.0.1",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor = mydb.cursor()
query=f"INSERT INTO product (ProductName,Price,Description,Photo) values ('{ProductName}', '{Price}', '{Description}', '{uploudFileName}')"""
#print(query)
mycursor.execute(query)
mydb.commit()
pro_id=mycursor.lastrowid
#print(pro_id)
upload_dir = f"""Product/{pro_id}"""
#print(upload_dir)
os.makedirs(upload_dir, exist_ok=True)
file_path=os.path.join(upload_dir,uploudFileName)
open(file_path,'wb').write(fi.file.read())
print(f'''
    <script>alert(" Product Add Successfully!");
    location.href="ProductList.py";
    </script>''')