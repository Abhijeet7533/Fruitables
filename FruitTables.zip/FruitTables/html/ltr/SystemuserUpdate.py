#!C:\Python312\python.exe
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html\n")
import mysql.connector
form=cgi.FieldStorage()
id=form.getvalue("id")
#print(id)
username=form.getvalue("username")
#print(username)
password=form.getvalue("password")
#print(password)
email=form.getvalue("email")
#print(email)

mydb = mysql.connector.connect(
    host="localhost",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
#print(mydb)
mycursor=mydb.cursor()
query=f""" UPDATE adminlogin SET username='{username}' , password='{password}' , email='{email}' WHERE id={id}"""
#print(query)   
mycursor.execute(query)
mydb.commit()
print(f'''
    <script>alert(" System Update Successfully");
    location.href="SystemuserList.py";
    </script>''')
