#!C:\Python312\python.exe
import cgi
import cgitb
import mysql.connector
import Header
cgitb.enable()
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
id=form.getvalue("id")
#print(id)
mydb = mysql.connector.connect(
    host="127.0.0.1",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor=mydb.cursor()
query=f""" SELECT * FROM product WHERE Id={id}"""
#print(query)
mycursor.execute(query)
mydata=mycursor.fetchone()
#print(mydata)
print(f"""
<!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Employee Master</h4>
                        <div class="d-flex align-items-center">
                           
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Product Form</h4>
                                
                                <form class="m-t-30" action="ProductBackEnd.py" method="POST">
                                    <div class="form-group">
                                        <label>Product Name</label>
                                        <input type="text" class="form-control" id="ProductName" Name="ProductName" value="{mydata[1]}">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label>Price</label>
                                        <input type="text" class="form-control" id="Price" Name="Price" value="{mydata[2]}">
                                    </div>
                                     <div class="form-group">
                                        <label>Description</label>
                                        <input type="text" class="form-control" id="Description" Name="Description" value="{mydata[3]}">
                                    </div>
                                     <div class="form-group">
                                        <label>ProductImage</label>
                                        <input type="file" class="form-control" id="Photo" Name="Photo" value="{mydata[4]}">
                                    </div>
                                    <div class="custom-control custom-checkbox mr-sm-2 m-b-15">
                                        
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
""")
import Footer