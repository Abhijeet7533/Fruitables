#!C:\Python312\python.exe
import cgi
import cgitb
import Header
cgitb.enable()
import mysql.connector
print("Content-Type: text/html\n")
form=cgi.FieldStorage()
#print(form)
UserID=form.getvalue("UserID")
#print(UserID)
mydb = mysql.connector.connect(
    host="localhost",  # IMPORTANT: use IP, not 'localhost'
    port="3306",
    user="root",
    password="",  
    database="fruitable_db",
    ssl_disabled=True,  # disables SSL completely (recommended for local dev)
    use_pure=True
)
mycursor = mydb.cursor(dictionary=True) 
query=f""" SELECT * FROM register  WHERE id='{UserID}' """
print(query)
mycursor.execute(query)
myResult=mycursor.fetchone()
#print(myResult)
print("""
<!DOCTYPE html>
<html>
<head>
<title>Register Form</title>
<style>
body{font-family:Arial;background:#f3f4f6;}
.form-box{
    width:400px;
    margin:50px auto;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px #ccc;
}
input,button{
    width:100%;
    padding:10px;
    margin:8px 0;
}
button{
    background:black;
    color:white;
    border:none;
    cursor:pointer;
}
</style>
</head>
""")
print(f"""
<body>

<div class="form-box">
<h2>User Registration</h2>

<form action="register_save.py" method="post">

<input type="text" name="FirstName" value="{myResult['FirstName']}"  readonly>
<input type="text" name="LastName" value="{myResult['LastName']}"   readonly>
<input type="email" name="Email" value="{myResult['Email']}"  readonly>
<input type="text" name="Street" value="{myResult['Street']}"  readonly>
<input type="text" name="City" value="{myResult['City']}"  readonly>
<input type="text" name="PinCode" value="{myResult['PinCode']}"  readonly>
<input type="text" name="PhoneNumber" value="{myResult['PhoneNumber']}"    readonly>
<input type="password" name="Password" value="{myResult['Password']}"  >

<button type="submit">Register Now</button>

</form>
</div>

</body>
</html>
""")