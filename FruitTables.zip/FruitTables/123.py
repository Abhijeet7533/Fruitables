#!C:\Python312\python.exe
import cgi
import cgitb
import Header
cgitb.enable()
print("Content-Type: text/html\n")
print("""
<!DOCTYPE html>
<html lang="en">
 
 

""")
import Footer