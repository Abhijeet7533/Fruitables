#!C:\Python312\python.exe
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html\n")
import Header
print("""
      <!DOCTYPE html>
<html lang="en">

<head>
    <title>Zay Shop eCommerce HTML CSS Template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
      <style>label {
    font-weight: 600;
    color: #666;
}
body {
  background: #f1f1f1;
}
.box8{
  box-shadow: 0px 0px 5px 1px #999;
}
.mx-t3{
  margin-top: -3rem;
}</style>
</head>

<body style="margin-top:50px;">
  <div class="container mt-3" >
  <form action="RegistrationBackEnd.py" method="POST">
    <div class="row jumbotron box8">
      <div class="col-sm-12 mx-t3 mb-4">
        <h2 class="text-center text-info" style="margin-top: 67px;">Register</h2>
      </div>
      <div class="col-sm-6 form-group">
        <label>First Name</label>
        <input type="text" class="form-control" name="FirstName" id="FirstName" placeholder="Enter your first name." required>
      </div>
      <div class="col-sm-6 form-group">
        <label>Last name</label>
        <input type="text" class="form-control" name="LastName" id="LastName" placeholder="Enter your last name." required>
      </div>
      <div class="col-sm-6 form-group">
        <label>Email</label>
        <input type="email" class="form-control" name="Email" id="Email" placeholder="Enter your email." required>
      </div>
      <div class="col-sm-6 form-group">
        <label>Street</label>
        <input type="text" class="form-control" name="Street" id="Street" placeholder="Locality/House/Street no." required>
      </div>
      <div class="col-sm-6 form-group">
        <label> City</label>
        <input type="text" class="form-control" name="City" id="City" placeholder="Village/City Name." required>
      </div>
      <div class="col-sm-2 form-group">
        <label>Pin-code</label>
        <input type="int" class="form-control" name="PinCode" id="PinCode" placeholder="Pin-Code." required>
      </div>
      <div class="col-sm-6 form-group">
        <label>Phone Number</label>
        <input type="text" name="PhoneNumber" class="form-control" id="PhoneNumber" placeholder="" required>
      </div>
      <div class="col-sm-6 form-group">
        <label>Password</label>
        <input type="text" name="Password" class="form-control" id="Password" placeholder="" required>
      </div>
      
      

      <div class="col-sm-12 form-group mb-0">
        <button type="submit" class="btn btn-primary float-right">Submit</button>
      </div>

    </div>
  </form>
</div>
""")
import Footer